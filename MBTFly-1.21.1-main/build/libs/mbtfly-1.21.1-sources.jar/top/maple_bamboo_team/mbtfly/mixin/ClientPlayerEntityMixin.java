package top.maple_bamboo_team.mbtfly.mixin;

import top.maple_bamboo_team.mbtfly.util.AimingUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.maple_bamboo_team.mbtfly.client.MBTFlyClient;
import top.maple_bamboo_team.mbtfly.client.flight.FlightControl;
import java.time.Instant;
import java.time.Duration;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_442;
import net.minecraft.class_746;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin {

    @Unique
    private static final double Y_TOLERANCE = 0.5;
    @Unique
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.SIMPLIFIED_CHINESE).withZone(ZoneId.systemDefault());
    @Unique
    private static final class_2561 PREFIX = class_2561.method_43470("[Maple Client] [MBTFly] ");
    @Unique
    private int autoExitCountdown = 0;
    @Unique
    private boolean elytraLowDurabilityWarning = false;

    @Unique
    private boolean isElytraLowDurability(class_746 player) {
        class_1799 chestplate = player.method_6118(class_1304.field_6174);
        if (chestplate.method_7909() == class_1802.field_8833) {
            int durability = chestplate.method_7919();
            int maxDurability = chestplate.method_7936();
            return durability >= maxDurability * 0.93; // 耐久不足7%
        }
        return false;
    }

    @Unique
    private class_243 findNearestLandingSpot(class_746 player) {
        class_243 playerPos = player.method_19538();
        class_1937 world = player.method_5770();
        
        // 搜索半径
        int searchRadius = 100;
        int bestY = -1;
        class_243 bestPos = null;
        double minDistance = Double.MAX_VALUE;
        
        // 在XZ平面上搜索
        for (int x = (int)(playerPos.field_1352 - searchRadius); x <= (int)(playerPos.field_1352 + searchRadius); x += 10) {
            for (int z = (int)(playerPos.field_1350 - searchRadius); z <= (int)(playerPos.field_1350 + searchRadius); z += 10) {
                // 从当前高度向下搜索地面
                for (int y = (int)playerPos.field_1351; y >= 0; y--) {
                    if (!world.method_22347(new net.minecraft.class_2338(x, y, z))) {
                        // 找到地面，检查是否是安全的着陆点
                        if (y > 0 && world.method_22347(new net.minecraft.class_2338(x, y + 1, z))) {
                            class_243 landingPos = new class_243(x, y + 1, z);
                            double distance = playerPos.method_1022(landingPos);
                            
                            // 选择最近的陆地
                            if (distance < minDistance) {
                                minDistance = distance;
                                bestPos = landingPos;
                                bestY = y;
                            }
                        }
                        break;
                    }
                }
            }
        }
        
        return bestPos;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        class_746 player = (class_746) (Object) this;

        if (client == null || client.field_1687 == null || player == null) {
            return;
        }

        // 检查是否在末地
        boolean isInEnd = player.method_5770().method_27983().method_29177().equals(net.minecraft.class_2960.method_60655("minecraft", "the_end"));
        
        // 如果在末地且正在飞行，检查鞘翅耐久
        if (isInEnd && FlightControl.enabled && isElytraLowDurability(player)) {
            if (!elytraLowDurabilityWarning) {
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §c警告: 鞘翅耐久不足7%，正在寻找最近的着陆点..."), false);
                elytraLowDurabilityWarning = true;
            }
            
            // 寻找最近的着陆点
            class_243 landingSpot = findNearestLandingSpot(player);
            if (landingSpot != null) {
                MBTFlyClient.destination = landingSpot;
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §a找到着陆点: §b" + 
                    String.format("%.1f", landingSpot.field_1352) + ", " + 
                    String.format("%.1f", landingSpot.field_1351) + ", " + 
                    String.format("%.1f", landingSpot.field_1350)), false);
            } else {
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §c未找到合适的着陆点，请手动降落"), false);
            }
        } else {
            elytraLowDurabilityWarning = false;
        }

        if (FlightControl.enabled) {
            client.field_1690.field_1894.method_23481(false);
            client.field_1690.field_1913.method_23481(false);
            client.field_1690.field_1849.method_23481(false);
            client.field_1690.field_1881.method_23481(false);
            client.field_1690.field_1903.method_23481(false);
            client.field_1690.field_1832.method_23481(false);
        }

        if (autoExitCountdown > 0) {
            autoExitCountdown--;
            if (autoExitCountdown % 20 == 0) {
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §6在 §f" + (autoExitCountdown / 20) + " §6秒后自动退出..."), false);
            }
            if (autoExitCountdown <= 0) {
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §6正在退出"), false);
                new Thread(() -> {
                    try {
                        Thread.sleep(800);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    client.execute(() -> {
                        if (client.field_1687 != null) {
                            client.field_1687.method_8525();
                            // 移除这行，因为 client.disconnect() 不接受 Text 参数
                            // client.disconnect(Text.literal("MBTFly: 到达目的地,自动退出"));
                            client.method_1507(new class_442());
                        }
                    });
                }).start();
                autoExitCountdown = -1;
            }
            return;
        }

        if (FlightControl.enabled && MBTFlyClient.destination != null) {
            class_243 playerPos = player.method_19538();

            class_243 flatPlayerPos = new class_243(playerPos.field_1352, MBTFlyClient.destination.field_1351, playerPos.field_1350);
            double flatDistance = flatPlayerPos.method_1022(MBTFlyClient.destination);

            double totalDistance = playerPos.method_1022(MBTFlyClient.destination);

            boolean ascentIssue = flatDistance <= MBTFlyClient.detectionRange && playerPos.field_1351 < MBTFlyClient.destination.field_1351 - Y_TOLERANCE;
            boolean reachedDestination = totalDistance <= MBTFlyClient.detectionRange;

            if (ascentIssue || reachedDestination) {
                FlightControl.enabled = false;

                client.field_1690.field_1894.method_23481(false);
                client.field_1690.field_1903.method_23481(false);
                client.field_1690.field_1832.method_23481(false);

                Instant endTime = Instant.now();
                Duration flightDuration = Duration.between(MBTFlyClient.startTime, endTime).minus(MBTFlyClient.pausedDuration);
                double originalTotalDistance = MBTFlyClient.startPos.method_1022(MBTFlyClient.destination);

                long totalSeconds = flightDuration.getSeconds();
                long days = totalSeconds / (24 * 3600);
                long hours = (totalSeconds % (24 * 3600)) / 3600;
                long minutes = (totalSeconds % 3600) / 60;
                long seconds = totalSeconds % 60;

                StringBuilder timeString = new StringBuilder();
                if (days > 0) timeString.append(days).append("天");
                if (hours > 0) timeString.append(hours).append("时");
                if (minutes > 0) timeString.append(minutes).append("分");
                timeString.append(seconds).append("秒");

                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §a============================================="), false);
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §a            MBTFly 自动飞行数据统计             "), false);
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §a============================================="), false);
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §b玩家名: §f" + MBTFlyClient.playerName), false);
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §b开始时间: §f" + formatter.format(MBTFlyClient.startTime)), false);
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §b结束时间: §f" + formatter.format(endTime)), false);
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §b总耗时: §f" + timeString.toString()), false);
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §b总路程: §f" + String.format("%.2f 格", originalTotalDistance)), false);
                player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §a============================================="), false);

                if (ascentIssue) {
                    player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] \n§c没有足够的距离拉升到目标高度,请指定足够远的距离以拉升高度"), false);
                }

                if (MBTFlyClient.autoExitEnabled && !MBTFlyClient.autoExitTriggered) {
                    MBTFlyClient.autoExitTriggered = true;
                    autoExitCountdown = 200;
                    player.method_7353(class_2561.method_43470("[Maple Client] [MBTFly] §6已到达目的地, 10秒后自动退出游戏"), false);
                }
            } else if (flatDistance <= MBTFlyClient.detectionRange) {
                client.field_1690.field_1894.method_23481(false);
                client.field_1690.field_1913.method_23481(false);
                client.field_1690.field_1849.method_23481(false);
                client.field_1690.field_1881.method_23481(false);

                if (playerPos.field_1351 < MBTFlyClient.destination.field_1351 - Y_TOLERANCE) {
                    client.field_1690.field_1903.method_23481(true);
                    client.field_1690.field_1832.method_23481(false);
                } else if (playerPos.field_1351 > MBTFlyClient.destination.field_1351 + Y_TOLERANCE) {
                    client.field_1690.field_1903.method_23481(false);
                    client.field_1690.field_1832.method_23481(true);
                } else {
                    client.field_1690.field_1903.method_23481(false);
                    client.field_1690.field_1832.method_23481(false);
                }
            } else {
                double yaw = AimingUtils.getYaw(playerPos, MBTFlyClient.destination);
                double pitch = AimingUtils.getPitch(playerPos, MBTFlyClient.destination);
                double yawDiff = yaw - player.method_36454();
                double pitchDiff = pitch - player.method_36455();

                if (yawDiff > 180) {
                    yawDiff -= 360;
                } else if (yawDiff < -180) {
                    yawDiff += 360;
                }

                float newYaw = (float) (player.method_36454() + yawDiff);
                float newPitch = (float) (player.method_36455() + pitchDiff);

                player.method_36456(newYaw);
                player.method_36457(newPitch);

                client.field_1690.field_1894.method_23481(true);

                if (playerPos.field_1351 < MBTFlyClient.destination.field_1351 - Y_TOLERANCE) {
                    client.field_1690.field_1903.method_23481(true);
                    client.field_1690.field_1832.method_23481(false);
                } else if (playerPos.field_1351 > MBTFlyClient.destination.field_1351 + Y_TOLERANCE) {
                    client.field_1690.field_1903.method_23481(false);
                    client.field_1690.field_1832.method_23481(true);
                } else {
                    client.field_1690.field_1903.method_23481(false);
                    client.field_1690.field_1832.method_23481(false);
                }
            }
        }
    }
}